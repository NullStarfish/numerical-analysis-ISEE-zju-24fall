def NewtonMethod(f, x):
    if abs(f(x)) < 0.0001:
        return x
    else:
        next = x - f(x)/different(f, x)
        return NewtonMethod(f, next)

def different(f, x):
    deltax = x + 0.0001
    return (f(deltax) - f(x)) / (deltax - x)


