(1):

$\epsilon_k = 1 - bx_k, g(x_k) = 2x_k - bx_k^2 = x_{k+1}$

$so that \epsilon_{k+1} = 1 - 2bx_k + b^2x_k^2$

prof..

(2)

$g(x) = 2x - bx^2$

$g'(x) = 2 - 2bx,  $
while $ 0 < x < 2/b $

$|g'(x)| < 1, prof.$