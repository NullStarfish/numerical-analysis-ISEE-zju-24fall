since A is symmetric:
$A^t = A$

to proove $\rho^2(A) = \rho(A^tA)$

$\rho^2(A) = \rho(A^2)$

proof.